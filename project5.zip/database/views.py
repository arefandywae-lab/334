from django.shortcuts import render, redirect
from database.models import Person, PersonForm

# Create your views here.
def create_person(request):
    form = PersonForm()
    if request.method == "POST":
        form = PersonForm(request.POST)
        if form.is_valid():
            form.save()
    
    data = {
        "form": form,
    }
    return render(request, "database/create_person.html", data)

def read_person(request):
    query = request.GET.get('q', '')
    if query:
        from django.db.models import Q
        persons = Person.objects.filter(
            Q(first_name__icontains=query) | Q(last_name__icontains=query)
        )
    else:
        persons = Person.objects.all()
    
    data = {
        "persons": persons,
        "query": query,
    }
    return render(request, "database/read_person.html", data)

def update_person(request, id):  # ← เพิ่มฟังก์ชันนี้ที่บรรทัด 24
    person = Person.objects.get(id=id)
    if request.method == "POST":
        form = PersonForm(request.POST, instance=person)
        if form.is_valid():
            form.save()
    else:
        form = PersonForm(instance=person)
    
    data = {
        "form": form,
    }
    return render(request, "database/update_person.html", data)

def delete_person(request, id):  # ← เพิ่มฟังก์ชันนี้ที่บรรทัด 38
    person = Person.objects.get(id=id)
    if request.method == "POST":
        person.delete()
        return redirect("read_person")
    
    data = {
        "person": person,
    }
    return render(request, "database/delete_person.html", data)
